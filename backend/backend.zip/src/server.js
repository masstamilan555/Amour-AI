dotenv.config();
import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';


import authRoutes from './routes/auth.route.js';
import { errorHandler } from './middleware/errorHandler.js';




const app = express();


app.use(helmet());
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(cookieParser());


app.use('/api/auth', authRoutes);


app.get('/', (req, res) => {
res.json({ ok: true, message: 'Auth API running' });
});


app.use(errorHandler);


async function start() {
await mongoose.connect(process.env.MONGODB_URI);
console.log('MongoDB connected');


app.listen(process.env.PORT, () => {
console.log(`Server running on port ${process.env.PORT}`);
});
}


start();
