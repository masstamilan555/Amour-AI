import mongoose from 'mongoose';
const { Schema } = mongoose;


const SessionSchema = new Schema({
userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
createdAt: { type: Date, default: () => new Date() },
expiresAt: { type: Date, required: true },
revoked: { type: Boolean, default: false }
});


SessionSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

export default mongoose.model('Session', SessionSchema);