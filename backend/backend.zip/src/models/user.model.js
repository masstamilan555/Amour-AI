import mongoose from 'mongoose';
const { Schema } = mongoose;


const UserSchema = new Schema({
phone: { type: String, required: true, unique: true },
phoneVerified: { type: Boolean, default: false },
affiliateId: { type: Schema.Types.ObjectId, default: null },
createdAt: { type: Date, default: () => new Date() },
lastLoginAt: { type: Date }
});


export default mongoose.model('User', UserSchema);