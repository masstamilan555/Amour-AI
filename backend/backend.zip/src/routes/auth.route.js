
import express from 'express';
import User from '../models/user.model.js';
import Session from '../models/session.model.js';
import { sendOtp, verifyOtp } from '../services/twilio.service.js';
import { normalizePhone } from '../utils/phoneNormalize.js';

const router = express.Router();

// POST /api/auth/send-otp
router.post('/send-otp', async (req, res, next) => {
  try {
    const { phone, username } = req.body;
    if (!phone) return res.status(400).json({ ok: false, error: 'phone_required' });

    const normalized = normalizePhone(phone);
    await sendOtp(phone);

    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/verify-otp
router.post('/verify-otp', async (req, res, next) => {
  try {
    const { phone, code } = req.body;
    if (!phone || !code) {
      return res.status(400).json({ ok: false, error: 'phone_and_code_required' });
    }

    const normalized = normalizePhone(phone);
    const result = await verifyOtp(normalized, code);

    if (result.status !== 'approved') {
      return res.status(400).json({ ok: false, error: 'invalid_otp' });
    }

    let user = await User.findOne({ phone: normalized });
    const now = new Date();

    if (!user) {
      const affiliateCode = req.cookies?.affiliate_ref || null;
      user = await User.create({
        phone: normalized,
        phoneVerified: true,
        affiliateId: affiliateCode,
        createdAt: now,
        lastLoginAt: now
      });
    } else {
      user.phoneVerified = true;
      user.lastLoginAt = now;
      await user.save();
    }

    const expiresAt = new Date(Date.now() + Number(process.env.SESSION_TTL_DAYS) * 86400000);
    const session = await Session.create({ userId: user._id, expiresAt });

    res.cookie('sid', session._id.toString(), {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      domain: process.env.COOKIE_DOMAIN
    });

    res.json({
      ok: true,
      user: {
        _id: user._id,
        phone: user.phone,
        affiliateId: user.affiliateId
      }
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/auth/me
router.get('/me', async (req, res, next) => {
  try {
    const sid = req.cookies?.sid;
    if (!sid) return res.status(401).json({ ok: false, error: 'not_logged_in' });

    const session = await Session.findById(sid);
    if (!session || session.revoked || session.expiresAt < new Date()) {
      return res.status(401).json({ ok: false, error: 'invalid_session' });
    }

    const user = await User.findById(session.userId).lean();
    if (!user) return res.status(404).json({ ok: false, error: 'user_not_found' });

    res.json({ ok: true, user });
  } catch (err) {
    next(err);
  }
});

export default router;

