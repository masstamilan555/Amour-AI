    export function normalizePhone(phone) {
    let p = phone.replace(/[^0-9+]/g, '');
    if (!p.startsWith('+')) {
    if (p.length === 10) p = '+91' + p;
    else p = '+' + p;
    }
    return p;
    }