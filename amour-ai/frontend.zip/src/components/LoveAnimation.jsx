import { Player } from '@lottiefiles/react-lottie-player';
// Import your specific JSON file
import animationData from '../assets/Heart.json';

const LoveAnimation = () => {
  return (
    <Player
      autoplay // Animation plays automatically when ready
      loop     // Animation loops continuously
      src={animationData} // Path to your JSON file data
      style={{ height: '300px', width: '300px' }} // Optional: set custom dimensions
    >
    </Player>
  );
};

export default LoveAnimation;
