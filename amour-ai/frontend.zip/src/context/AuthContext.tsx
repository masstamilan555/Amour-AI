import axios from 'axios';
import { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user1, setUser] = useState(null);

  // Example login function (would typically call an API)
  const loginApp = async (data) => {
    // Await API call, get user data and token
    // const response = await axios.post('/api/login', data);
    const fetchedUser = { name: 'Jane Doe', email: 'jane@example.com', credits: 100 };

    setUser(fetchedUser);
  };
  const fetchUser = async () => {
    try {
      const res = await axios.get("/api/auth/me");
       // with proxy you can omit host
      if (res.status !== 200 || !res.data.ok) {
        setUser(null);
        return;
      }
      setUser(res.data?.data); // <-- consistent shape
    } catch (err) {
      setUser(null);
    }
  };

  const logOutApp = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user1, loginApp, logOutApp, fetchUser }}>
      {children}
    </AuthContext.Provider>
  );
};

// eslint-disable-next-line react-refresh/only-export-components
export const useAuth = () => {
  return useContext(AuthContext);
};
